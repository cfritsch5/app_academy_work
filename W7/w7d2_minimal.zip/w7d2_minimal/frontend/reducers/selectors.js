const allTodos = ({todos}) => Object.keys(todos).map( (id) => todos[id]);

export default allTodos;
