function uniqueId() {
  return new Date().getTime();
}

export default uniqueId;
