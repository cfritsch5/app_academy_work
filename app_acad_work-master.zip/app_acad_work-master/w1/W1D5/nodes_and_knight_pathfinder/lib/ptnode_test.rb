#node3
node_4 = PolyTreeNode.new(4);
node_3 = PolyTreeNode.new(3, [node_4]);
node_2 = PolyTreeNode.new(2);
node_1 = PolyTreeNode.new(1, [node_2, node_3]);
