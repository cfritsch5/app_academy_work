require 'colorize'
require_relative 'board'
class Display

end 
