require_relative "static_array"

class RingBuffer
  attr_reader :length

  def initialize
    @capacity = 8
    @length = 0
    @start_idx = 0
    @store = StaticArray.new(@capacity)
  end

  # O(1)
  def [](index)
    check_index(index)
    @store[index]
  end

  # O(1)
  def []=(index, val)
    check_index(index)
    @store[index] = val
  end

  # O(1)
  def pop
    index = check_index(@length - 1)
    @length -= 1
    popped = @store[index]
    @store[index] = nil
    popped
  end

  # O(1) ammortized
  def push(val)
    @store[@length] = val
    @length += 1
  end

  # O(1)
  def shift
    check_index(@length - 1)
    puts "checked"
    shifted = @store[@start_idx]
    (@length + 1).times do |i|
      i = convert_index(i)
      @store[i] = @store[i+1]
    end
    @length -= 1
    shifted
  end

  # O(1) ammortized
  def unshift(val)
    @length += 1
    (@length).downto(0) do |i|
      @store[i] = @store[i-1]
    end
    @store[0] = val
  end

  protected
  attr_accessor :capacity, :start_idx, :store
  attr_writer :length

  def check_index(index)
    index = convert_index(index)
    raise "index out of bounds" if (index < 0 || index >= @length)
    index
  end

  def resize!
    old_store = @store
    @capacity = @capacity * 2
    @store = StaticArray.new(@capacity)
    @length.times do |i|
      @store[i] = old_store[i]
    end
  end

  def convert_index(index)
    (index + @start_idx) % @capacity
  end
end
