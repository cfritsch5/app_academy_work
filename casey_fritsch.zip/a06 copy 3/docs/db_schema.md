# Database Schema

## posts
column name | data type | details
------------|-----------|-----------------------
id          | integer   | not null, primary key
title       | string    | not null
body        | text      | not null
created_at  | datetime  | not null
updated_at  | datetime  | not null
