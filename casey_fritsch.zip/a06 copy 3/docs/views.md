# View Wireframes

## Post Index Page

![index wireframe][posts_index]

## Post Show Page

![show wireframe][posts_show]

## Post Edit Page

![edit wireframe][posts_edit]

[posts_index]: ./wireframes/posts_index.png
[posts_show]: ./wireframes/posts_show.png
[posts_edit]: ./wireframes/posts_edit.png
