export const RECEIVE_POSTS = "RECEIVE_POSTS";
export const RECEIVE_POST = "RECEIVE_POST";
export const NEW_POST = "RECEIVE_POST";
export const REMOVE_POST = "REMOVE_POST";
export const EDIT_POST = "EDIT_POST";

import * as Util from '../util/post_api_util';

export const receivePosts = (posts) => ({
  type: RECEIVE_POSTS,
  posts
});
export const receivePost = (post) => ({
  type: RECEIVE_POST,
  post
});
export const newPost = (post) => ({
  type: NEW_POST,
  post
});
export const removePost = (post) => ({
  type: REMOVE_POST,
  post
});
export const editPost = (post) => ({
  type: EDIT_POST,
  post
});
// export const receive_posts = (posts) => ({
//   type: RECEIVE_POSTS,
//   posts
// });
export const requestPosts = () => (dispatch) => {
  return Util.fetchPosts()
    .then(posts => dispatch(receivePosts(posts)));
};

export const requestPost = (id) => (dispatch) => {
  return Util.fetchPost(id).then(post => {
    dispatch(receivePost(post));
    return post;
  });
};
export const deletePost = post => (dispatch) => {
  return Util.deletePost(post).then(post => {
    dispatch(removePost(post));
  });
};
export const updatePost = post => (dispatch) => {
  return Util.editPost(post).then(post => {
    dispatch(receivePost(post));
  });
};

export const createPost = (Post) => (dispatch) => {
  return Util.createPost(Post)
    .then(post => dispatch(receivePost(post)));
};
