import React from 'react';
import { Provider } from 'react-redux';
import {
  Route,
  Redirect,
  Switch,
  Link,
  HashRouter
} from 'react-router-dom';
import PostsContainer from './posts_container';
import ShowPostContainer from './show_post_container';

const App = () => (
  <div>
    <Switch>
        <Route exact path="/" component={PostsContainer} />
        <Route path="/posts/:postId" component={ShowPostContainer} />
      </Switch>
  </div>
);

export default App;
