import React from 'react';
import PostForm from './post_form';
import { Link } from 'react-router-dom';

class EachPost extends React.Component {
  constructor(props) {
    super(props);

    this.state = {edit: false};

    this.deletePost = this.deletePost.bind(this);
    this.editPost = this.editPost.bind(this);
    this.toggleEdit = this.toggleEdit.bind(this);
  }

  deletePost(e) {
    e.preventDefault();
    this.props.deletePost(this.props.post);
  }

  editPost(e) {
    e.preventDefault();
    this.props.editPost(this.props.post);
  }

  toggleEdit(e) {
    e.preventDefault();
    this.setState({edit: !this.state.edit});

  }

  render() {
    let edit, editOrCancel;
    if (this.state.edit){
      edit = <PostForm
        edit={this.state.edit}
        updatePost={this.props.updatePost}
        post={this.props.post} />;
      editOrCancel = "CLOSE";
    } else {
      editOrCancel = "EDIT";
    }

  return  (
    <li>
      <h3>
        <Link to={`/posts/${this.props.post.id}`}>
          {this.props.post.title}
        </Link>
      </h3>
      <button
        id={this.props.post.id}
        onClick={this.deletePost}>
        DELETE
      </button>
      {edit}
      <button
        id={this.props.post.id}
        onClick={ this.toggleEdit }>
        {editOrCancel}
      </button>
    </li>
  );
  }
}

export default EachPost;
