import React from 'react';
import * as Actions from '../actions/post_actions';

class PostForm extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      title: "",
      body: "",
    };

    this.handleTitle = this.handleTitle.bind(this);
    this.handleBody = this.handleBody.bind(this);
    this.handleSubmit= this.handleSubmit.bind(this);
  }

  componentDidMount(){
    if (this.props.edit){
      this.setState(this.props.post);
    }
  }

  handleTitle(e) {
    const title = e.target.value;
    this.setState({title});
  }

  handleBody(e) {
    const body = e.target.value;
    this.setState({body});
  }

  handleSubmit(e) {
    e.preventDefault();
    if (this.props.edit) {
      let post = Object.assign({},this.state);
      console.log(this.props);
      this.props.updatePost({post});
    } else {
      if(this.state.title){
        let post = Object.assign({},this.state);
        this.props.createPost({post});
        console.log(this.props);
        this.setState({
          title: "",
          body: ""
        });
      }
   }
  }

  render(){
    // console.log("props",this.props);
    // console.log("state",this.state);
    let submit;
    if (this.props.edit) {
      submit = "Edit";
    } else {
      submit = "Post";
    }
    return (
      <div className="post-form">
        <form>
          <label>Title: <input
              onChange={this.handleTitle}
              value={this.state.title}/>
            </label>
        <label>Body: <textarea
              rows='5'
              cols='20'
              onChange={this.handleBody}
              value={this.state.body}></textarea></label>
            <button onClick={this.handleSubmit}>Submit {submit}</button>
        </form>
      </div>
    );
  }
}

export default PostForm;
