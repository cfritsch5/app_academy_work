import React from 'react';
import EachPost from './each_post';
import PostForm from './post_form';
import PostFormContainer from './post_form_container';
import { Route } from 'react-router-dom';


class Posts extends React.Component {
  componentDidMount() {
    this.props.requestPosts();
  }

  render() {
    const { posts, receivePost, removePost, updatePost, deletePost} = this.props;

    const postlist = posts.map(post => (
      <EachPost
        key={`each-post${post.id}`}
        post={post}
        deletePost={deletePost}
        updatePost={updatePost}
        />
      )
    );

    return(
      <div className="post-list">
        <ul >
          { postlist }
        </ul>
        <PostFormContainer />
      </div>
    );
  }
}

export default Posts;
