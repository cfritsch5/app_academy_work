import {connect} from 'react-redux';
import Posts from './posts';

import {requestPosts,
        receivePosts,
        receivePost,
        removePost,
        createPost,
        deletePost,
        updatePost
      } from '../actions/post_actions';

import {allPosts} from '../reducers/selectors';

const mapStateToProps = (state) => ({
  posts: allPosts(state),
  state
});

const mapDispatchToProps = (dispatch) => ({
  createPost: () => dispatch(createPost()),
  requestPosts: () => dispatch(requestPosts()),
  receivePosts: ()=> dispatch(receivePosts()),
  receivePost: post => dispatch(receivePost(post)),
  removePost: post => dispatch(removePost(post)),
  deletePost: post => dispatch(deletePost(post)),
  updatePost: post => dispatch(updatePost(post)),
});
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Posts);
