import React from 'react';
import { Route } from 'react-router-dom';

class ShowPost extends React.Component {
  constructor(props) {
    super(props);

    this.state= {
      id: "",
      title:"",
      body:""
    };
  }

  componentDidMount() {
    this.props.requestPost(this.props.match.params.postId);
    console.log(this.props);
  }

  componentWillReceiveProps(nextProps) {
      console.log(nextProps);
      this.setState(nextProps.posts[this.props.match.params.postId]);

  }

  render() {
    console.log(this.props.posts);
    return (
      <section className="show-post">
        <h1>{this.state.title}</h1>
        <p>{this.state.body}</p>
      </section>
    );
  }
}

export default ShowPost;
