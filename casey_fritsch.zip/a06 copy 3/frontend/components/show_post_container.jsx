import { connect } from 'react-redux';
import ShowPost from './show_post';
import { requestPost } from '../actions/post_actions';
import {selectPost} from '../reducers/selectors';

// const mapStateToProps = (state,{ match}) => {
const mapStateToProps = ({posts}) => ({
  // const postId = parseInt(match.params.postId);
  // const post = selectPost(state, match.params.postId);
  //
  // return {
  // postId,
  // post
  // };
  posts
});

const mapDispatchToProps = dispatch => ({
  requestPost: id => dispatch(requestPost(id))
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ShowPost);
