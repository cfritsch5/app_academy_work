import React from 'react';
import ReactDOM from 'react-dom';
import Root from './components/root';
import {configureStore} from './store/store';


// TESTING GROUP
import {allPosts} from './reducers/selectors';
import * as Actions from './actions/post_actions';
import postsReducer from './reducers/posts_reducer';
import PostsContainer from './components/posts_container';
import * as PostUtil from './util/post_api_util';


document.addEventListener('DOMContentLoaded', () => {

  const store = configureStore();

//TESTING GROUP
  window.store = store;
  window.allPosts = allPosts;
  window.Actions = Actions;
  window.postsReducer = postsReducer;
  window.PostUtil = PostUtil;
  //TESTING GROUP

  const root = document.getElementById('root');
  ReactDOM.render(<Root store={store}/>, root);
});
