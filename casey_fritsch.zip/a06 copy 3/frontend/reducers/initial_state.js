const initialState = {
  1: {
    id: 1,
    title: "SOMETHING IS TERRIBLY WRONG",
    body: "OH SH__"},
};

export default initialState;
