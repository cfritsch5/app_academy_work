
import { RECEIVE_POSTS,
         RECEIVE_POST,
         REMOVE_POST,
         EDIT_POST,
         NEW_POST
       } from '../actions/post_actions';
import merge from 'lodash/merge';
import initialState from './initial_state';


const postsReducer = (state = initialState, action) => {
  Object.freeze(state);
  let nextState;

  switch(action.type){
    case RECEIVE_POSTS:
      nextState = {};
      return merge({},state, action.posts);
    case RECEIVE_POST:
      nextState = {};
      return merge({}, state, {[action.post.id]: action.post});
    case NEW_POST:
      const newPost = {[action.post.id]: action.post};
      return Object.assign({}, state, newPost);
    case REMOVE_POST:
      nextState = merge({}, state);
      delete nextState[action.post.id];
      return nextState;
    case EDIT_POST:
      nextState = merge({}, state);
      delete nextState[action.post.id];
      const editedPost = {[action.post.id]: action.post};
      return Object.assign({}, state, editedPost);
    // case post_ERROR:
    //   alert(action.error);
    default:
      return state;
  }
};

export default postsReducer;
