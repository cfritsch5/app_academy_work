import {combineReducers} from 'redux';
import postsReducer from './posts_reducer';

const RootReducer = combineReducers({
  posts: postsReducer,
});

export default RootReducer;
