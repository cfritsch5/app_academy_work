export const allPosts = (state) => (
  Object.keys(state.posts).map(id => state.posts[id])
);

// export const selectPost = ({post}, id) => {
//   const curr_post = post[id] || {};
//   return curr_post;
// };
