import {createStore, applyMiddleware} from 'redux';
import RootReducer from '../reducers/root_reducer';
// import thunk from '../middleware/thunk_middleware';
import thunk from 'redux-thunk';

export const configureStore = (initialState = {}) => (
  createStore(RootReducer, applyMiddleware(thunk))
);
// import { createStore, applyMiddleware } from 'redux';
// import thunk from 'redux-thunk';
// import logger from 'redux-logger';
//
// import RootReducer from '../reducers/root_reducer';
//
// const configureStore = () => (
//   createStore(RootReducer, applyMiddleware(thunk, logger))
// );
//
// export default configureStore;
