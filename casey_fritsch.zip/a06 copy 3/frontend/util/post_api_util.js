export const fetchPosts = () => (
  $.ajax({
    method: 'GET',
    url: '/api/posts'
  })
);

export const fetchPost = id => (
  $.ajax({
    method: 'GET',
    url: `/api/posts/${id}`,
  })
);

export const createPost = post => {
  console.log(post);
 return $.ajax({
    method: 'POST',
    url: '/api/posts',
    data: post
  });
};

export const editPost = post => (
  $.ajax({
    method: 'PATCH',
    url: `/api/posts/${post.id}`,
    post: { post }
  })
);

export const deletePost = post => (
  $.ajax({
    method: 'DELETE',
    url: `api/posts/${post.id}`
  })
);
