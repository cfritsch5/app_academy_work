# Be sure to restart your server when you modify this file.

PostsApp::Application.config.session_store :cookie_store, key: '_PostsApp_session'
