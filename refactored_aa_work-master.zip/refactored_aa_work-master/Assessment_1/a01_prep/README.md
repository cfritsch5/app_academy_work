# a01-prep

Assessment 1 will test general programming knowledge.

## How to prepare

The following is a (non-exhaustive) list of topics that may be covered:

+ Searches and Sorts
+ Recursion
+ Enumerables
+ Arrays, Strings, Hashes
+ Monkey patching

Pro-tip: read the description of the failing spec, look at the spec code, and read the error message.
